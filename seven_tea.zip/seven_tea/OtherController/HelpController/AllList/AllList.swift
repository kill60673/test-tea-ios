//
//  AllList.swift
//  seven_tea
//
//  Created by harrison on 2020/3/3.
//  Copyright © 2020 harrison公司機. All rights reserved.
//

import Foundation
import UIKit

var memberCenterList: [String] = ["我的最愛", "帳戶資料", "常見問題", "服務及隱私條款"]
var memberCenterImageList  = ["heart", "people", "warring", "service"]
var accountInfoList: [String] = ["頭像", "帳號", "用戶名", "性別", "綁定手機", "設定Email", "修改密碼", "推播通知"]
var addressList: [String] = ["常用1", "常用2", "常用3"]
var notifyList: [String] = []
var faqList: [String] = ["帳戶資料", "購物流程", "外送規範", "飲品內容", "與我合作", "意見回饋"]
var genderList: [String] = ["男", "女"]
var setnotifyList:[String] = ["推播通知", "Email通知"]
var resetpasswordList:[String] = ["輸入舊密碼", "輸入新密碼", "再次輸入新密碼"]
var setemailList: [String] = ["Email"]
