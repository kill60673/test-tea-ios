//
//  RegexMessage.swift
//  seven_tea
//
//  Created by harrison on 2020/2/15.
//  Copyright © 2020 harrison公司機. All rights reserved.
//

import Foundation

class RegexMessage: NSObject {
    let inputExcepion = "＊格式錯誤請重新輸入"
    let phoneNoinput = "＊請輸入電話號碼"
    let accountNoinput = "＊請輸入帳號"
    let passwordNoinput = "＊請輸入密碼"
    let verificationcodeNoinput = "＊請輸入電話驗證碼"
    let emailNoinput = "＊請輸入電子信箱"
}
