//
//  AddFeedBackViewController.swift
//  seven_tea
//
//  Created by harrison on 2020/3/11.
//  Copyright © 2020 harrison公司機. All rights reserved.
//

import UIKit

class AddFeedBackViewController: UIViewController {
    @IBOutlet weak var tfTitle: UITextField!
    @IBOutlet weak var tvContent: UITextView!
    @IBOutlet weak var pvType: UIPickerView!
    @IBOutlet weak var btSumbit: UIBarButtonItem!
    
    override func viewDidLoad() {
        super.viewDidLoad()


    }
}
